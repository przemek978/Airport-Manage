export class Employee{
  constructor(private name:string,private surname:string,private position:string,private username:string,private password:string ){

  }
}
